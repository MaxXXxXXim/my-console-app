# Console App

Проста консольна програма, яка виводить аргументи командного рядка.

## Запуск

python main.py hello world

## Приклад виводу

Arguments received:
0: main.py
1: hello
2: world
